import 'package:flutter/material.dart';
// import '../l10n/app_localizations.dart';
import '../widgets/shared_text.dart';
import '../theme/app_colors.dart';

class ScheduleMessagePage extends StatefulWidget {
  const ScheduleMessagePage({super.key});

  @override
  State<ScheduleMessagePage> createState() => _ScheduleMessagePageState();
}

class _ScheduleMessagePageState extends State<ScheduleMessagePage> {
  final TextEditingController _messageController = TextEditingController();
  final FocusNode _messageFocus = FocusNode();

  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;

  bool _isScheduling = false;

  static const int _maxChars = 500;

  @override
  void initState() {
    super.initState();
    _messageController.addListener(_refresh);
    _messageFocus.addListener(_refresh);
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    _messageController.removeListener(_refresh);
    _messageFocus.removeListener(_refresh);
    _messageController.dispose();
    _messageFocus.dispose();
    super.dispose();
  }

  // =====================================================
  // Helpers
  // =====================================================

  DateTime? get _scheduledDateTime {
    if (_selectedDate == null || _selectedTime == null) return null;
    return DateTime(
      _selectedDate!.year,
      _selectedDate!.month,
      _selectedDate!.day,
      _selectedTime!.hour,
      _selectedTime!.minute,
    );
  }

  bool get _hasAnything =>
      _messageController.text.trim().isNotEmpty ||
      _selectedDate != null ||
      _selectedTime != null;

  String get _countdownText {
    final dt = _scheduledDateTime;
    if (dt == null) return 'Pick a date and time to see the countdown';

    final diff = dt.difference(DateTime.now());
    if (diff.isNegative) return 'That moment has already passed';

    if (diff.inDays >= 365) {
      final years = (diff.inDays / 365).floor();
      return 'Arrives in $years ${years == 1 ? 'year' : 'years'}';
    }
    if (diff.inDays >= 1) {
      return 'Arrives in ${diff.inDays} ${diff.inDays == 1 ? 'day' : 'days'}';
    }
    if (diff.inHours >= 1) {
      return 'Arrives in ${diff.inHours} ${diff.inHours == 1 ? 'hour' : 'hours'}';
    }
    return 'Arrives in ${diff.inMinutes} minutes';
  }

  ThemeData _pickerTheme(BuildContext context) {
    return Theme.of(context).copyWith(
      colorScheme: const ColorScheme.light(
        primary: AppColors.darkBlue,
        onPrimary: Colors.white,
        surface: Colors.white,
        onSurface: AppColors.darkBlue,
      ),
      dialogBackgroundColor: Colors.white,
    );
  }

  Future<void> _selectDate() async {
    final now = DateTime.now();

    final DateTime? pickedDate = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? now,
      firstDate: now,
      lastDate: DateTime(now.year + 5),
      builder: (context, child) =>
          Theme(data: _pickerTheme(context), child: child!),
    );

    if (pickedDate != null) {
      setState(() => _selectedDate = pickedDate);
    }
  }

  Future<void> _selectTime() async {
    final TimeOfDay? pickedTime = await showTimePicker(
      context: context,
      initialTime: _selectedTime ?? TimeOfDay.now(),
      builder: (context, child) =>
          Theme(data: _pickerTheme(context), child: child!),
    );

    if (pickedTime != null) {
      setState(() => _selectedTime = pickedTime);
    }
  }

  void _applyQuickPick(Duration duration) {
    final target = DateTime.now().add(duration);
    setState(() {
      _selectedDate = DateTime(target.year, target.month, target.day);
      _selectedTime ??= TimeOfDay(hour: target.hour, minute: target.minute);
    });
  }

  // =====================================================
  // Schedule Message
  // =====================================================

  Future<void> _scheduleMessage() async {
    FocusScope.of(context).unfocus();

    final message = _messageController.text.trim();

    if (message.isEmpty) {
      _showMessage('Write your message first.');
      return;
    }
    if (_selectedDate == null) {
      _showMessage('Choose the date it should arrive.');
      return;
    }
    if (_selectedTime == null) {
      _showMessage('Choose the time it should arrive.');
      return;
    }

    final scheduledDateTime = _scheduledDateTime!;

    if (scheduledDateTime.isBefore(DateTime.now())) {
      _showMessage('That time has passed. Pick a later one.');
      return;
    }

    setState(() => _isScheduling = true);

    try {
      // TODO: Save the scheduled message to Firebase here.
      await Future.delayed(const Duration(seconds: 1));

      if (!mounted) return;
      setState(() => _isScheduling = false);
      _showSuccessMessage();
    } catch (e) {
      if (!mounted) return;
      setState(() => _isScheduling = false);
      _showMessage('The message was not saved. Try again.');
    }
  }

  // =====================================================
  // Snack bars
  // =====================================================

  void _showSnack(String message, Color background, IconData icon) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          backgroundColor: background,
          margin: const EdgeInsets.all(16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          content: Row(
            children: [
              Icon(icon, color: AppColors.gold, size: 20),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  message,
                  style: const TextStyle(color: Colors.white),
                ),
              ),
            ],
          ),
        ),
      );
  }

  void _showMessage(String message) =>
      _showSnack(message, AppColors.darkBlue, Icons.info_outline_rounded);

  void _showSuccessMessage() => _showSnack(
    'Scheduled. It will reach you on time.',
    const Color(0xFF1B5E20),
    Icons.check_circle_outline_rounded,
  );

  // =====================================================
  // Date Formatting
  // =====================================================

  String _getDateText() {
    if (_selectedDate == null) return 'Not set';
    return '${_selectedDate!.day.toString().padLeft(2, '0')}/'
        '${_selectedDate!.month.toString().padLeft(2, '0')}/'
        '${_selectedDate!.year}';
  }

  String _getTimeText() {
    if (_selectedTime == null) return 'Not set';
    return _selectedTime!.format(context);
  }

  // =====================================================
  // Build
  // =====================================================

  @override
  Widget build(BuildContext context) {
    //final t = AppLocalizations.of(context)!;

    return Scaffold(
      backgroundColor: AppColors.primaryColor,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          onPressed: () {
            Navigator.pushReplacementNamed(context, '/home');
          },
          icon: Icon(Icons.arrow_back),
        ),
        title: SharedText(
          title: 'Schedule Message',
          colorString: AppColors.darkBlue,
          fontNum: 20,
          fontWeight: FontWeight.bold,
        ),
        iconTheme: const IconThemeData(color: AppColors.darkBlue),
      ),

      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [AppColors.primaryColor, Colors.white],
            stops: [0.0, 0.75],
          ),
        ),

        child: SafeArea(
          child: GestureDetector(
            onTap: () => FocusScope.of(context).unfocus(),
            behavior: HitTestBehavior.opaque,

            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 36),

              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  _buildHeader(),
                  const SizedBox(height: 26),

                  _buildSectionTitle('Your message', 'Only you will read it.'),
                  const SizedBox(height: 10),
                  _buildMessageField(),

                  const SizedBox(height: 26),

                  _buildSectionTitle(
                    'Delivery time',
                    'Pick a moment in the future.',
                  ),
                  const SizedBox(height: 10),
                  _buildQuickPicks(),
                  const SizedBox(height: 12),

                  Row(
                    children: [
                      Expanded(
                        child: _buildSelectionCard(
                          icon: Icons.calendar_month_rounded,
                          title: 'Date',
                          value: _getDateText(),
                          isSet: _selectedDate != null,
                          onTap: _selectDate,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _buildSelectionCard(
                          icon: Icons.access_time_rounded,
                          title: 'Time',
                          value: _getTimeText(),
                          isSet: _selectedTime != null,
                          onTap: _selectTime,
                        ),
                      ),
                    ],
                  ),

                  // Preview (animated)
                  AnimatedSize(
                    duration: const Duration(milliseconds: 250),
                    curve: Curves.easeOut,
                    alignment: Alignment.topCenter,
                    child: _hasAnything
                        ? Padding(
                            padding: const EdgeInsets.only(top: 26),
                            child: _buildPreview(),
                          )
                        : const SizedBox(width: double.infinity),
                  ),

                  const SizedBox(height: 28),
                  _buildScheduleButton(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // =====================================================
  // Header
  // =====================================================

  Widget _buildHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(22, 26, 22, 24),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.darkBlue, Color(0xFF16305A)],
        ),
        boxShadow: [
          BoxShadow(
            color: AppColors.darkBlue.withOpacity(0.25),
            blurRadius: 22,
            offset: const Offset(0, 10),
          ),
        ],
      ),

      child: Column(
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: Colors.white.withOpacity(0.08),
              border: Border.all(color: AppColors.gold, width: 1.6),
            ),
            child: const Icon(
              Icons.schedule_rounded,
              size: 32,
              color: AppColors.gold,
            ),
          ),

          const SizedBox(height: 14),

          const Text(
            'A message for your future self',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white,
              fontSize: 20,
              fontWeight: FontWeight.bold,
              height: 1.3,
            ),
          ),

          const SizedBox(height: 8),

          Text(
            'Write it now, receive it exactly when you choose.',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.white.withOpacity(0.75),
              fontSize: 13,
              height: 1.5,
            ),
          ),
        ],
      ),
    );
  }

  // =====================================================
  // Section title
  // =====================================================

  Widget _buildSectionTitle(String title, String subtitle) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 4,
          height: 34,
          margin: const EdgeInsets.only(top: 2, right: 10),
          decoration: BoxDecoration(
            color: AppColors.gold,
            borderRadius: BorderRadius.circular(4),
          ),
        ),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                title,
                style: const TextStyle(
                  color: AppColors.darkBlue,
                  fontSize: 17,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                subtitle,
                style: TextStyle(
                  color: AppColors.darkBlue.withOpacity(0.55),
                  fontSize: 12.5,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // =====================================================
  // Message field
  // =====================================================

  Widget _buildMessageField() {
    final focused = _messageFocus.hasFocus;
    final length = _messageController.text.characters.length;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      padding: const EdgeInsets.fromLTRB(16, 6, 16, 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(
          color: focused ? AppColors.darkBlue : AppColors.gold,
          width: focused ? 1.6 : 1.0,
        ),
        boxShadow: [
          BoxShadow(
            color: focused
                ? AppColors.darkBlue.withOpacity(0.10)
                : Colors.black.withOpacity(0.04),
            blurRadius: focused ? 18 : 10,
            offset: const Offset(0, 6),
          ),
        ],
      ),

      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          TextField(
            controller: _messageController,
            focusNode: _messageFocus,
            maxLines: 7,
            minLines: 5,
            maxLength: _maxChars,
            textInputAction: TextInputAction.newline,
            textAlignVertical: TextAlignVertical.top,
            cursorColor: AppColors.darkBlue,
            style: const TextStyle(
              color: AppColors.darkBlue,
              fontSize: 15,
              height: 1.5,
            ),
            decoration: InputDecoration(
              counterText: '',
              hintText: 'What do you want to remember, or be reminded of?',
              hintStyle: TextStyle(
                color: AppColors.darkBlue.withOpacity(0.35),
                fontSize: 14.5,
              ),
              border: InputBorder.none,
              contentPadding: const EdgeInsets.symmetric(vertical: 12),
            ),
          ),

          Text(
            '$length / $_maxChars',
            style: TextStyle(
              fontSize: 11.5,
              color: length >= _maxChars
                  ? Colors.redAccent
                  : AppColors.darkBlue.withOpacity(0.45),
            ),
          ),
        ],
      ),
    );
  }

  // =====================================================
  // Quick picks
  // =====================================================

  Widget _buildQuickPicks() {
    final options = <String, Duration>{
      'Tomorrow': const Duration(days: 1),
      'In a week': const Duration(days: 7),
      'In a month': const Duration(days: 30),
      'In a year': const Duration(days: 365),
    };

    return SizedBox(
      height: 38,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        itemCount: options.length,
        separatorBuilder: (_, __) => const SizedBox(width: 8),
        itemBuilder: (context, index) {
          final label = options.keys.elementAt(index);
          final duration = options.values.elementAt(index);

          final target = DateTime.now().add(duration);
          final isActive =
              _selectedDate != null &&
              _selectedDate!.year == target.year &&
              _selectedDate!.month == target.month &&
              _selectedDate!.day == target.day;

          return InkWell(
            onTap: () => _applyQuickPick(duration),
            borderRadius: BorderRadius.circular(30),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 160),
              padding: const EdgeInsets.symmetric(horizontal: 16),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: isActive ? AppColors.darkBlue : Colors.white,
                borderRadius: BorderRadius.circular(30),
                border: Border.all(
                  color: isActive ? AppColors.darkBlue : AppColors.gold,
                ),
              ),
              child: Text(
                label,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: isActive ? AppColors.gold : AppColors.darkBlue,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  // =====================================================
  // Selection Card
  // =====================================================

  Widget _buildSelectionCard({
    required IconData icon,
    required String title,
    required String value,
    required bool isSet,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),

      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.all(15),
        decoration: BoxDecoration(
          color: isSet ? AppColors.goldTrans.withOpacity(0.30) : Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppColors.gold, width: isSet ? 1.5 : 1.0),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.04),
              blurRadius: 10,
              offset: const Offset(0, 5),
            ),
          ],
        ),

        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: AppColors.darkBlue, size: 20),
                const SizedBox(width: 7),
                Text(
                  title,
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 13.5,
                    color: AppColors.darkBlue,
                  ),
                ),
                const Spacer(),
                Icon(
                  Icons.expand_more_rounded,
                  size: 18,
                  color: AppColors.darkBlue.withOpacity(0.5),
                ),
              ],
            ),

            const SizedBox(height: 10),

            Text(
              value,
              style: TextStyle(
                color: isSet
                    ? AppColors.darkBlue
                    : AppColors.darkBlue.withOpacity(0.4),
                fontSize: 15,
                fontWeight: isSet ? FontWeight.bold : FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // =====================================================
  // Preview
  // =====================================================

  Widget _buildPreview() {
    final message = _messageController.text.trim();

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.gold),
        boxShadow: [
          BoxShadow(
            color: AppColors.goldTrans,
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),

      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(
                Icons.mark_email_unread_outlined,
                color: AppColors.darkBlue,
                size: 19,
              ),
              const SizedBox(width: 7),
              const Text(
                'Preview',
                style: TextStyle(
                  color: AppColors.darkBlue,
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const Spacer(),
              Text(
                '${_getDateText()}  ·  ${_getTimeText()}',
                style: TextStyle(
                  color: AppColors.darkBlue.withOpacity(0.6),
                  fontSize: 12,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),

          const SizedBox(height: 14),

          // Message bubble
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppColors.primaryColor,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(16),
                topRight: Radius.circular(16),
                bottomRight: Radius.circular(16),
                bottomLeft: Radius.circular(4),
              ),
            ),
            child: Text(
              message.isEmpty ? 'Your message will appear here.' : message,
              style: TextStyle(
                color: message.isEmpty
                    ? AppColors.darkBlue.withOpacity(0.4)
                    : AppColors.darkBlue,
                fontSize: 14.5,
                height: 1.55,
                fontStyle: message.isEmpty
                    ? FontStyle.italic
                    : FontStyle.normal,
              ),
            ),
          ),

          const SizedBox(height: 14),

          Row(
            children: [
              const Icon(
                Icons.hourglass_bottom_rounded,
                size: 17,
                color: AppColors.darkBlue,
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  _countdownText,
                  style: const TextStyle(
                    color: AppColors.darkBlue,
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // =====================================================
  // Schedule Button
  // =====================================================

  Widget _buildScheduleButton() {
    return SizedBox(
      height: 54,
      child: DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          boxShadow: _isScheduling
              ? const []
              : [
                  BoxShadow(
                    color: AppColors.darkBlue.withOpacity(0.30),
                    blurRadius: 16,
                    offset: const Offset(0, 8),
                  ),
                ],
        ),
        child: ElevatedButton.icon(
          onPressed: _isScheduling ? null : _scheduleMessage,
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.darkBlue,
            disabledBackgroundColor: AppColors.darkBlue.withOpacity(0.45),
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
              side: const BorderSide(color: AppColors.gold, width: 1.2),
            ),
          ),
          icon: _isScheduling
              ? const SizedBox(
                  width: 19,
                  height: 19,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: AppColors.gold,
                  ),
                )
              : const Icon(Icons.schedule_send_rounded, color: AppColors.gold),
          label: Text(
            _isScheduling ? 'Scheduling' : 'Schedule message',
            style: const TextStyle(
              fontSize: 16.5,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
        ),
      ),
    );
  }
}

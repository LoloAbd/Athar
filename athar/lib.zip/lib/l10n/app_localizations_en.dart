// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get appName => 'Athar';

  @override
  String get appTagline => 'A little message at the right time.';

  @override
  String get home => 'Home';

  @override
  String get welcomeBack => 'Welcome back';

  @override
  String get welcomeMessage =>
      'A little kindness at the right time can make a big difference.';

  @override
  String get signUpMessage =>
      'Join us today and start your journey with a personalized experience made for you';

  @override
  String get loginpMessage =>
      'Sign in to continue your journey and explore everything we have prepared for you';

  @override
  String get login => 'Log in';

  @override
  String get logout => 'Log out';

  @override
  String get signUp => 'Register';

  @override
  String get or => 'Or continue with';

  @override
  String get signUpWithGoogle => 'Google';

  @override
  String get createAccount => 'Create your account';

  @override
  String get email => 'Email Address';

  @override
  String get password => 'Password';

  @override
  String get confirmPassword => 'Confirm password';

  @override
  String get name => 'Name';

  @override
  String get username => 'Username';

  @override
  String get usernameRequired => 'Username is required.';

  @override
  String get invalidUsername =>
      'Username must be 3–20 characters and can only contain letters, numbers, and underscores.';

  @override
  String get enterEmail => 'Enter your email';

  @override
  String get enterPassword => 'Enter your password';

  @override
  String get enterName => 'Enter your name';

  @override
  String get enterUsername => 'Enter username';

  @override
  String get emailRequired => 'Email is required';

  @override
  String get invalidEmail => 'Please enter a valid email';

  @override
  String get passwordRequired => 'Password is required';

  @override
  String get passwordMinLength => 'Password must be at least 8 characters';

  @override
  String get passwordUppercase => 'Password must contain an uppercase letter';

  @override
  String get passwordNumber => 'Password must contain a number';

  @override
  String get weakpassword => 'The password is too weak';

  @override
  String get nameRequired => 'Name is required';

  @override
  String get invalidName => 'Please enter a valid name';

  @override
  String get remmberMe => 'Remmber me';

  @override
  String get forgotPassword => 'Forgot your password?';

  @override
  String get resetPassword => 'Reset password';

  @override
  String get noAccount => 'Don\'t have an account?';

  @override
  String get alreadyHaveAccount => 'Already have an account?';

  @override
  String get passwordsDoNotMatch => 'Passwords do not match.';

  @override
  String get userNotFound => 'No account found with this email.';

  @override
  String get faildlogin => 'Login failed';

  @override
  String get requiredField => 'This field is required.';

  @override
  String get invalidCredentials => 'Incorrect email or password.';

  @override
  String get emailAlreadyInUse => 'This email is already in use.';

  @override
  String get accountCreated => 'Your account has been created.';

  @override
  String get goodMorning => 'Good Morning, ';

  @override
  String get goodAfternoon => 'Good Afternoon, ';

  @override
  String get goodEvening => 'Good Evening, ';

  @override
  String get todayMessage => 'Today\'s message';

  @override
  String get favorites => 'Favorites';

  @override
  String get history => 'History';

  @override
  String get quickActions => 'Quick actions';

  @override
  String get datesjoin => 'Date\'s Joined';

  @override
  String get all => 'All';

  @override
  String get ayat => 'Ayat';

  @override
  String get quotes => 'Qoutes';

  @override
  String get favoriteMessages => 'Favorite Messages';

  @override
  String get favorite => 'Add to favorites';

  @override
  String get unfavorite => 'Remove from favorites';

  @override
  String get schedule => 'Schedule';

  @override
  String get randomUser => 'Random Person';

  @override
  String get reminder => 'Reminder';

  @override
  String get reminderMessage =>
      'Congrats on your failures, most people don\'t even try. Note: they are not failures if you learned something from them';

  @override
  String get noHistory => 'You haven\'t received any messages yet.';

  @override
  String get settings => 'Profile settings';

  @override
  String get account => 'Account';

  @override
  String get profile => 'My Profile';

  @override
  String get profileMessage => 'Keep spreading positivity ';

  @override
  String get profileTitle => 'Spread kindness';

  @override
  String get profileSubtitle => 'Your words can make someone\'s day';

  @override
  String get language => 'Language';

  @override
  String get privacy => 'Privacy';

  @override
  String get about => 'About';

  @override
  String get english => 'English';

  @override
  String get arabic => 'Arabic';

  @override
  String get noMessages => 'No messages yet.';

  @override
  String get noFavorites => 'No favorite messages yet.';

  @override
  String get noScheduledMessages => 'No scheduled messages yet.';

  @override
  String get save => 'Save';

  @override
  String get cancel => 'Cancel';

  @override
  String get delete => 'Delete';

  @override
  String get edit => 'Edit';

  @override
  String get add => 'Add';

  @override
  String get create => 'Create';

  @override
  String get update => 'Update';

  @override
  String get done => 'Done';

  @override
  String get continueButton => 'Continue';

  @override
  String get back => 'Back';

  @override
  String get next => 'Next';

  @override
  String get close => 'Close';

  @override
  String get confirm => 'Confirm';

  @override
  String get yes => 'Yes';

  @override
  String get no => 'No';

  @override
  String get retry => 'Retry';

  @override
  String get ok => 'OK';

  @override
  String get search => 'Search';

  @override
  String get loading => 'Loading...';

  @override
  String get seeAll => 'See all';

  @override
  String get enabled => 'Enabled';

  @override
  String get disabled => 'Disabled';

  @override
  String get on => 'On';

  @override
  String get off => 'Off';

  @override
  String get am => 'AM';

  @override
  String get pm => 'PM';

  @override
  String get minutes => 'minutes';

  @override
  String get hours => 'hours';

  @override
  String get days => 'days';

  @override
  String get randomMessage => 'Random Message';

  @override
  String get surpriseForFutureSelf => 'A surprise for your future self';

  @override
  String get randomMessageDescription =>
      'Just write it. We will choose a random moment within the next five years and deliver it to you.';

  @override
  String get yourMessage => 'Your message';

  @override
  String get writeSomethingForFutureSelf =>
      'Write something for your future self.';

  @override
  String get messageHint => 'What do you want your future self to read?';

  @override
  String get surpriseIsWaiting => 'A surprise is waiting';

  @override
  String get deliveryTimeDescription =>
      'The delivery time is chosen randomly by the system. You will not know when your message will arrive.';

  @override
  String get sending => 'Sending...';

  @override
  String get sendToTheFuture => 'Send to the future';

  @override
  String get writeMessageFirst => 'Write your message first.';

  @override
  String get messageSentSuccess => 'Sent to your future self ✨';

  @override
  String get messageNotSaved => 'The message was not saved. Try again.';
}

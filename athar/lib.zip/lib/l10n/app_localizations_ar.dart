// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Arabic (`ar`).
class AppLocalizationsAr extends AppLocalizations {
  AppLocalizationsAr([String locale = 'ar']) : super(locale);

  @override
  String get appName => 'أثر';

  @override
  String get appTagline => 'رسالة صغيرة في الوقت المناسب.';

  @override
  String get home => 'الرئيسية';

  @override
  String get welcomeBack => 'أهلًا بعودتك';

  @override
  String get welcomeMessage =>
      'كلمة لطيفة في الوقت المناسب يمكن أن تصنع فرقًا.';

  @override
  String get signUpMessage =>
      'انضم إلينا اليوم وابدأ رحلتك بتجربة مخصصة تناسبك';

  @override
  String get loginpMessage =>
      'سجّل الدخول لمتابعة رحلتك واستكشاف كل ما أعددناه لك';

  @override
  String get login => 'تسجيل الدخول';

  @override
  String get logout => 'تسجيل الخروج';

  @override
  String get signUp => 'إنشاء حساب';

  @override
  String get or => ' أو أكمل باستخدام';

  @override
  String get signUpWithGoogle => 'جوجل';

  @override
  String get createAccount => 'أنشئ حسابك';

  @override
  String get email => 'البريد الإلكتروني';

  @override
  String get password => 'كلمة المرور';

  @override
  String get confirmPassword => 'تأكيد كلمة المرور';

  @override
  String get name => 'الاسم';

  @override
  String get username => 'اسم المستخدم';

  @override
  String get usernameRequired => 'اسم المستخدم مطلوب.';

  @override
  String get invalidUsername =>
      'يجب أن يكون اسم المستخدم بين 3 و20 حرفًا، ويمكن أن يحتوي فقط على الأحرف والأرقام والشرطة السفلية (_).';

  @override
  String get enterEmail => 'يرجى إدخال بريدك الإلكتروني.';

  @override
  String get enterPassword => 'أدخل كلمة المرور';

  @override
  String get enterName => 'أدخل اسمك';

  @override
  String get enterUsername => 'ادخل اسم المستخدم';

  @override
  String get emailRequired => 'البريد الإلكتروني مطلوب';

  @override
  String get invalidEmail => 'يرجى إدخال بريد إلكتروني صحيح.';

  @override
  String get passwordRequired => 'كلمة المرور مطلوبة';

  @override
  String get passwordMinLength => 'يجب أن تكون كلمة المرور 8 أحرف على الأقل';

  @override
  String get passwordUppercase => 'يجب أن تحتوي كلمة المرور على حرف كبير';

  @override
  String get passwordNumber => 'يجب أن تحتوي كلمة المرور على رقم';

  @override
  String get weakpassword => 'كلمة المرور ضعيفة';

  @override
  String get nameRequired => 'الاسم مطلوب';

  @override
  String get invalidName => 'يرجى إدخال اسم صحيح';

  @override
  String get remmberMe => 'تذكرني';

  @override
  String get forgotPassword => 'نسيت كلمة المرور؟';

  @override
  String get resetPassword => 'إعادة تعيين كلمة المرور';

  @override
  String get noAccount => 'ليس لديك حساب؟';

  @override
  String get alreadyHaveAccount => 'لديك حساب بالفعل؟';

  @override
  String get passwordsDoNotMatch => 'كلمتا المرور غير متطابقتين.';

  @override
  String get userNotFound => 'لا يوجد حساب مرتبط بهذا البريد الإلكتروني.';

  @override
  String get faildlogin => 'فشل تسجيل الدخول';

  @override
  String get requiredField => 'هذا الحقل مطلوب.';

  @override
  String get invalidCredentials =>
      'البريد الإلكتروني أو كلمة المرور غير صحيحة.';

  @override
  String get emailAlreadyInUse => 'هذا البريد الإلكتروني مستخدم بالفعل.';

  @override
  String get accountCreated => 'تم إنشاء حسابك.';

  @override
  String get goodMorning => 'صباح الخير، ';

  @override
  String get goodAfternoon => 'مساء الخير، ';

  @override
  String get goodEvening => 'مساء الخير، ';

  @override
  String get todayMessage => 'رسالة اليوم';

  @override
  String get favorites => 'المفضلة';

  @override
  String get history => 'السجل';

  @override
  String get quickActions => 'إجراءات سريعة';

  @override
  String get datesjoin => 'تاريخ الانضمام';

  @override
  String get all => 'الكل';

  @override
  String get ayat => 'آيات';

  @override
  String get quotes => 'اقتباسات';

  @override
  String get favoriteMessages => 'الرسائل المفضلة';

  @override
  String get favorite => 'إضافة إلى المفضلة';

  @override
  String get unfavorite => 'إزالة من المفضلة';

  @override
  String get schedule => 'الجدولة';

  @override
  String get randomUser => 'شخص عشوائي';

  @override
  String get reminder => 'تذكير';

  @override
  String get reminderMessage =>
      'مبارك لك على فشلك، فمعظم الناس لا يحاولون حتى، ملاحظة: إذا تعلمت منها درسا فهي لا تعد فشلا';

  @override
  String get noHistory => 'لم تستلم أي رسائل حتى الآن.';

  @override
  String get settings => 'إعدادات الحساب';

  @override
  String get account => 'الحساب';

  @override
  String get profile => 'حسابي';

  @override
  String get profileMessage => 'استمر في نشر الإيجابية';

  @override
  String get profileTitle => 'أنشر الإيجابية';

  @override
  String get profileSubtitle => 'كلماتك يمكن أن تصنع يوم أحدهم';

  @override
  String get language => 'اللغة';

  @override
  String get privacy => 'الخصوصية';

  @override
  String get about => 'حول التطبيق';

  @override
  String get english => 'الإنجليزية';

  @override
  String get arabic => 'العربية';

  @override
  String get noMessages => 'لا توجد رسائل حتى الآن.';

  @override
  String get noFavorites => 'لا توجد رسائل مفضلة حتى الآن.';

  @override
  String get noScheduledMessages => 'لا توجد رسائل مجدولة حتى الآن.';

  @override
  String get save => 'حفظ';

  @override
  String get cancel => 'إلغاء';

  @override
  String get delete => 'حذف';

  @override
  String get edit => 'تعديل';

  @override
  String get add => 'إضافة';

  @override
  String get create => 'إنشاء';

  @override
  String get update => 'تحديث';

  @override
  String get done => 'تم';

  @override
  String get continueButton => 'متابعة';

  @override
  String get back => 'رجوع';

  @override
  String get next => 'التالي';

  @override
  String get close => 'إغلاق';

  @override
  String get confirm => 'تأكيد';

  @override
  String get yes => 'نعم';

  @override
  String get no => 'لا';

  @override
  String get retry => 'إعادة المحاولة';

  @override
  String get ok => 'حسنًا';

  @override
  String get search => 'بحث';

  @override
  String get loading => 'جارٍ التحميل...';

  @override
  String get seeAll => 'عرض الكل';

  @override
  String get enabled => 'مفعّل';

  @override
  String get disabled => 'معطّل';

  @override
  String get on => 'تشغيل';

  @override
  String get off => 'إيقاف';

  @override
  String get am => 'ص';

  @override
  String get pm => 'م';

  @override
  String get minutes => 'دقائق';

  @override
  String get hours => 'ساعات';

  @override
  String get days => 'أيام';

  @override
  String get randomMessage => 'رسالة عشوائية';

  @override
  String get surpriseForFutureSelf => 'مفاجأة لنفسك في المستقبل';

  @override
  String get randomMessageDescription =>
      'اكتب رسالتك فقط، وسنختار وقتًا عشوائيًا خلال السنوات الخمس القادمة لإرسالها إليك.';

  @override
  String get yourMessage => 'رسالتك';

  @override
  String get writeSomethingForFutureSelf => 'اكتب شيئًا لنفسك في المستقبل.';

  @override
  String get messageHint =>
      'ماذا تريد أن تقرأه عندما تصلك الرسالة في المستقبل؟';

  @override
  String get surpriseIsWaiting => 'هناك مفاجأة بانتظارك';

  @override
  String get deliveryTimeDescription =>
      'يختار النظام وقت الإرسال بشكل عشوائي، ولن تعرف متى ستصل رسالتك.';

  @override
  String get sending => 'جارٍ الإرسال...';

  @override
  String get sendToTheFuture => 'أرسل إلى المستقبل';

  @override
  String get writeMessageFirst => 'اكتب رسالتك أولًا.';

  @override
  String get messageSentSuccess => 'تم إرسال رسالتك إلى نفسك في المستقبل ✨';

  @override
  String get messageNotSaved => 'لم يتم حفظ الرسالة. حاول مرة أخرى.';
}
